// ===================================
// Smooth Scrolling Navigation
// ===================================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');

        if (targetId === '#') return;

        const targetElement = document.querySelector(targetId);

        if (targetElement) {
            const headerOffset = 80;
            const elementPosition = targetElement.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });

            // Close mobile menu if open
            const navList = document.querySelector('.nav-list');
            navList.classList.remove('active');
        }
    });
});

// ===================================
// Mobile Menu Toggle
// ===================================

const mobileMenuToggle = document.getElementById('mobileMenuToggle');
const navList = document.querySelector('.nav-list');

mobileMenuToggle.addEventListener('click', () => {
    navList.classList.toggle('active');
    mobileMenuToggle.classList.toggle('active');
});

// Close menu when clicking outside
document.addEventListener('click', (e) => {
    if (!e.target.closest('.header-content')) {
        navList.classList.remove('active');
        mobileMenuToggle.classList.remove('active');
    }
});

// ===================================
// Active Navigation Link on Scroll
// ===================================

const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-link');

function updateActiveNavLink() {
    const scrollPosition = window.scrollY + 100;

    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.offsetHeight;
        const sectionId = section.getAttribute('id');

        if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${sectionId}`) {
                    link.classList.add('active');
                }
            });
        }
    });
}

window.addEventListener('scroll', updateActiveNavLink);
window.addEventListener('load', updateActiveNavLink);

// ===================================
// Sticky Header
// ===================================

const header = document.getElementById('header');
let lastScrollTop = 0;

window.addEventListener('scroll', () => {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    // Header shadow removed per design requirements
    lastScrollTop = scrollTop;
});

// ===================================
// Testimonials Carousel
// ===================================

const testimonialsTrack = document.getElementById('testimonialsTrack');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');

let currentTestimonial = 0;
const testimonialCards = document.querySelectorAll('.testimonial-card');
const totalTestimonials = testimonialCards.length;

function updateCarousel() {
    const cardWidth = testimonialCards[0].offsetWidth;
    const gap = 30; // Match CSS gap
    const scrollAmount = (cardWidth + gap) * currentTestimonial;

    testimonialsTrack.scrollTo({
        left: scrollAmount,
        behavior: 'smooth'
    });
}

function scrollCarousel(direction) {
    const cardWidth = testimonialCards[0].offsetWidth;
    const gap = 30;
    const scrollAmount = cardWidth + gap;

    if (direction === 'next') {
        testimonialsTrack.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });
    } else {
        testimonialsTrack.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });
    }
}

function nextTestimonial() {
    currentTestimonial = (currentTestimonial + 1) % totalTestimonials;
    updateCarousel();
}

function prevTestimonial() {
    currentTestimonial = (currentTestimonial - 1 + totalTestimonials) % totalTestimonials;
    updateCarousel();
}

nextBtn.addEventListener('click', () => scrollCarousel('next'));
prevBtn.addEventListener('click', () => scrollCarousel('prev'));

// Auto-play carousel (optional - uncomment to enable)
/*
let autoplayInterval = setInterval(nextTestimonial, 5000);

// Pause autoplay on hover
testimonialsTrack.addEventListener('mouseenter', () => {
    clearInterval(autoplayInterval);
});

testimonialsTrack.addEventListener('mouseleave', () => {
    autoplayInterval = setInterval(nextTestimonial, 5000);
});
*/

// Update carousel on window resize
window.addEventListener('resize', updateCarousel);

// ===================================
// Form Handling
// ===================================

const heroForm = document.getElementById('heroForm');
const footerForm = document.getElementById('footerForm');

function handleFormSubmit(e) {
    e.preventDefault();

    const formData = new FormData(e.target);
    const firstName = e.target.querySelector('input[type="text"]').value;
    const email = e.target.querySelector('input[type="email"]').value;

    // Basic validation
    if (!firstName || !email) {
        showFormMessage(e.target, 'Please fill in all fields', 'error');
        return;
    }

    if (!isValidEmail(email)) {
        showFormMessage(e.target, 'Please enter a valid email address', 'error');
        return;
    }

    // Here you would typically send the data to your backend
    console.log('Form submitted:', { firstName, email });

    // Show success message
    showFormMessage(e.target, 'Thanks! We\'ll be in touch soon.', 'success');

    // Reset form
    e.target.reset();
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function showFormMessage(form, message, type) {
    // Remove any existing message
    const existingMessage = form.querySelector('.form-message');
    if (existingMessage) {
        existingMessage.remove();
    }

    // Create new message element
    const messageEl = document.createElement('div');
    messageEl.className = `form-message form-message-${type}`;
    messageEl.textContent = message;
    messageEl.style.cssText = `
        margin-top: 15px;
        padding: 12px 20px;
        border-radius: 8px;
        font-weight: 500;
        text-align: center;
        background-color: ${type === 'success' ? '#78C952' : '#E85D54'};
        color: white;
        animation: slideIn 0.3s ease;
    `;

    form.appendChild(messageEl);

    // Remove message after 5 seconds
    setTimeout(() => {
        messageEl.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => messageEl.remove(), 300);
    }, 5000);
}

// Add CSS animations for form messages
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes slideOut {
        from {
            opacity: 1;
            transform: translateY(0);
        }
        to {
            opacity: 0;
            transform: translateY(-10px);
        }
    }
`;
document.head.appendChild(style);

heroForm.addEventListener('submit', handleFormSubmit);
footerForm.addEventListener('submit', handleFormSubmit);

// ===================================
// Intersection Observer for Animations
// ===================================

const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe feature cards, ethos cards, etc. for fade-in animations
document.querySelectorAll('.feature-card, .ethos-card, .testimonial-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
});

// ===================================
// Loading & Initialization
// ===================================

document.addEventListener('DOMContentLoaded', () => {
    console.log('Podcast Club website loaded successfully!');

    // Add smooth scroll behavior to html element as fallback
    document.documentElement.style.scrollBehavior = 'smooth';

    // Initialize carousel position
    updateCarousel();
});

// ===================================
// Prevent form submission on Enter in input fields
// ===================================

document.querySelectorAll('.form-input').forEach(input => {
    input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && input.type !== 'submit') {
            e.preventDefault();
            const form = input.closest('form');
            const submitBtn = form.querySelector('button[type="submit"]');
            submitBtn.click();
        }
    });
});
